"use client";

import React, { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import CreateEmployeeSection from "../../components/CreateEmployeeSection";

type Role = "employee" | "local_admin" | "regional_admin" | "master_admin";

type Profile = {
  id: string;
  role: Role | string;
  location_id: string | null;
  region_id: string | null;
};

type Location = {
  id: string;
  name: string;
  region_id: string | null;
};

type TrackedItem = {
  id: string;
  location_id: string;
  name: string;
  sub_label: string | null;
  unit: string;
  value_per_unit: number;
  baseline_input: number | null;
  baseline_output: number | null;
  tolerance_green: number;
  tolerance_yellow: number;
  baseline_locked: boolean;
  active: boolean;
  created_at: string;
};

function asNumberOrNull(v: string): number | null {
  const t = v.trim();
  if (!t) return null;
  const n = Number(t);
  if (!Number.isFinite(n)) return null;
  return n;
}

function asNumber(v: string, fallback = 0): number {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return n;
}

function isAdminRole(role: string) {
  return role === "local_admin" || role === "regional_admin" || role === "master_admin";
}

function roleRank(role: string) {
  if (role === "employee") return 0;
  if (role === "local_admin") return 1;
  if (role === "regional_admin") return 2;
  if (role === "master_admin") return 3;
  return 0;
}

export default function AdminTrackedItemsPage() {
  const router = useRouter();

  const [authText, setAuthText] = useState("");
  const [status, setStatus] = useState("");

  const [profile, setProfile] = useState<Profile | null>(null);
  const [blocked, setBlocked] = useState(true);

  const [locations, setLocations] = useState<Location[]>([]);
  const [locationId, setLocationId] = useState<string>("");

  const [rows, setRows] = useState<TrackedItem[]>([]);
  const [loadingRows, setLoadingRows] = useState(false);

  const [q, setQ] = useState("");

  const [name, setName] = useState("");
  const [subLabel, setSubLabel] = useState("");
  const [unit, setUnit] = useState("bottle");

  const [valuePerUnit, setValuePerUnit] = useState("0");
  const [baselineInput, setBaselineInput] = useState("");
  const [baselineOutput, setBaselineOutput] = useState("");
  const [tGreen, setTGreen] = useState("0.03");
  const [tYellow, setTYellow] = useState("0.06");

  const [creating, setCreating] = useState(false);

  const myRole = String(profile?.role || "");
  const myLocationId = profile?.location_id ? String(profile.location_id) : "";
  const myRegionId = profile?.region_id ? String(profile.region_id) : "";

  const canAtLeastLocal = roleRank(myRole) >= roleRank("local_admin");
  const canAtLeastRegional = roleRank(myRole) >= roleRank("regional_admin");
  const isMaster = myRole === "master_admin";

  const locationsInScope = useMemo(() => {
    if (!profile) return [];

    if (isMaster) return locations;

    if (myRole === "regional_admin") {
      if (!myRegionId) return [];
      return locations.filter((l) => String(l.region_id || "") === myRegionId);
    }

    if (myRole === "local_admin") {
      if (!myLocationId) return [];
      return locations.filter((l) => l.id === myLocationId);
    }

    return [];
  }, [locations, profile, isMaster, myRole, myRegionId, myLocationId]);

  const selectedLocation = useMemo(() => {
    return locationsInScope.find((l) => l.id === locationId) || null;
  }, [locationsInScope, locationId]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r) => {
      const a = (r.name || "").toLowerCase();
      const b = (r.sub_label || "").toLowerCase();
      const c = (r.unit || "").toLowerCase();
      return a.includes(s) || b.includes(s) || c.includes(s) || r.id.toLowerCase().includes(s);
    });
  }, [rows, q]);

  async function loadRows(targetLocationId: string) {
    setStatus("");
    setLoadingRows(true);

    const { data, error } = await supabase
      .from("tracked_items")
      .select(
        "id,location_id,name,sub_label,unit,value_per_unit,baseline_input,baseline_output,tolerance_green,tolerance_yellow,baseline_locked,active,created_at"
      )
      .eq("location_id", targetLocationId)
      .order("active", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(1000);

    setLoadingRows(false);

    if (error) {
      setRows([]);
      setStatus(error.message);
      return;
    }

    setRows((data ?? []) as TrackedItem[]);
  }

  useEffect(() => {
    let cancelled = false;

    async function boot() {
      setStatus("");
      setBlocked(true);

      const { data } = await supabase.auth.getUser();
      if (!data?.user) {
        if (!cancelled) {
          setAuthText("Not signed in");
          router.replace("/login?next=" + encodeURIComponent("/admin/tracked-items"));
        }
        return;
      }

      if (!cancelled) setAuthText(`Signed in as ${data.user.email || data.user.id}`);

      const { data: prof, error: profErr } = await supabase
        .from("profiles")
        .select("id,role,location_id,region_id")
        .eq("id", data.user.id)
        .maybeSingle();

      if (profErr || !prof) {
        if (!cancelled) {
          setStatus(profErr?.message || "Could not load profile");
          router.replace("/login");
        }
        return;
      }

      const p = prof as Profile;

      if (!isAdminRole(String(p.role || ""))) {
        if (!cancelled) {
          router.replace("/employee");
        }
        return;
      }

      if (!cancelled) setProfile(p);

      const { data: locs, error: locErr } = await supabase
        .from("locations")
        .select("id,name,region_id")
        .order("name");

      if (locErr) {
        if (!cancelled) setStatus(locErr.message);
        return;
      }

      const allLocs = (locs ?? []) as Location[];
      if (!cancelled) setLocations(allLocs);

      let defaultLocationId = "";

      if (String(p.role) === "master_admin") {
        defaultLocationId = allLocs[0]?.id || "";
      } else if (String(p.role) === "regional_admin") {
        const first = allLocs.find((l) => String(l.region_id || "") === String(p.region_id || ""));
        defaultLocationId = first?.id || "";
      } else if (String(p.role) === "local_admin") {
        defaultLocationId = String(p.location_id || "");
      }

      if (!cancelled) setLocationId(defaultLocationId);

      if (defaultLocationId) {
        await loadRows(defaultLocationId);
      }

      if (!cancelled) setBlocked(false);
    }

    boot();

    return () => {
      cancelled = true;
    };
  }, [router]);

  useEffect(() => {
    if (blocked) return;
    if (!locationId) return;

    if (myRole === "local_admin") {
      if (myLocationId && locationId !== myLocationId) {
        setLocationId(myLocationId);
        return;
      }
    }

    const locOk = locationsInScope.some((l) => l.id === locationId);
    if (!locOk) return;

    loadRows(locationId);
  }, [locationId]);

  async function createTrackedItem() {
    setStatus("");

    if (!canAtLeastLocal) {
      setStatus("Access denied");
      return;
    }

    const locId = locationId || "";
    if (!locId) {
      setStatus("Select a location");
      return;
    }

    if (myRole === "local_admin" && myLocationId && locId !== myLocationId) {
      setStatus("Local admin must use their assigned location");
      return;
    }

    const nm = name.trim();
    if (!nm) {
      setStatus("Name is required");
      return;
    }

    const u = unit.trim();
    if (!u) {
      setStatus("Unit is required");
      return;
    }

    const vpu = asNumber(valuePerUnit, 0);
    const bi = asNumberOrNull(baselineInput);
    const bo = asNumberOrNull(baselineOutput);

    const tg = asNumber(tGreen, 0.03);
    const ty = asNumber(tYellow, 0.06);

    setCreating(true);

    const { error } = await supabase.from("tracked_items").insert({
      location_id: locId,
      name: nm,
      sub_label: subLabel.trim() ? subLabel.trim() : null,
      unit: u,
      value_per_unit: vpu,
      baseline_input: bi,
      baseline_output: bo,
      tolerance_green: tg,
      tolerance_yellow: ty,
      baseline_locked: false,
      active: true,
    });

    setCreating(false);

    if (error) {
      setStatus(error.message);
      return;
    }

    setStatus("Created tracked item");
    setName("");
    setSubLabel("");
    setUnit("bottle");
    setValuePerUnit("0");
    setBaselineInput("");
    setBaselineOutput("");
    setTGreen("0.03");
    setTYellow("0.06");

    await loadRows(locId);
  }

  async function toggleActive(row: TrackedItem) {
    setStatus("");

    if (!canAtLeastLocal) {
      setStatus("Access denied");
      return;
    }

    if (myRole === "local_admin" && myLocationId && row.location_id !== myLocationId) {
      setStatus("Out of scope");
      return;
    }

    const { error } = await supabase
      .from("tracked_items")
      .update({ active: !row.active })
      .eq("id", row.id);

    if (error) {
      setStatus(error.message);
      return;
    }

    await loadRows(row.location_id);
  }

  async function quickUpdate(row: TrackedItem, patch: Partial<TrackedItem>) {
    setStatus("");

    if (!canAtLeastLocal) {
      setStatus("Access denied");
      return;
    }

    if (myRole === "local_admin" && myLocationId && row.location_id !== myLocationId) {
      setStatus("Out of scope");
      return;
    }

    if (patch.baseline_locked === true && !isMaster) {
      setStatus("Only master admin can lock baselines");
      return;
    }

    const { error } = await supabase.from("tracked_items").update(patch).eq("id", row.id);

    if (error) {
      setStatus(error.message);
      return;
    }

    await loadRows(row.location_id);
  }

  if (blocked) {
    return (
      <div style={{ padding: 24, maxWidth: 1100 }}>
        <div style={{ fontSize: 20, fontWeight: 700 }}>Tracked items</div>
        <div style={{ fontSize: 12, opacity: 0.8, marginTop: 6 }}>{authText}</div>
        <div style={{ marginTop: 14, fontSize: 12, opacity: 0.9 }}>{status || "Blocked"}</div>
      </div>
    );
  }

  const locationDisabled = myRole === "local_admin";

  return (
    <div style={{ padding: 24, maxWidth: 1200 }}>
      <div style={{ fontSize: 20, fontWeight: 700 }}>Tracked items</div>
      <div style={{ fontSize: 12, opacity: 0.8, marginTop: 6 }}>{authText}</div>
      <div style={{ fontSize: 12, opacity: 0.75, marginTop: 6 }}>
        {profile ? `Role: ${String(profile.role)}` : ""}
      </div>

      <div style={{ marginTop: 16, display: "flex", gap: 10, alignItems: "end", flexWrap: "wrap" }}>
        <div style={{ minWidth: 320 }}>
          <div style={{ fontSize: 12, opacity: 0.8 }}>Location</div>
          <select
            value={locationId}
            onChange={(e) => setLocationId(e.target.value)}
            disabled={locationDisabled}
            style={{ marginTop: 6, padding: 10, width: "100%" }}
          >
            {locationsInScope.length === 0 ? <option value="">No locations in scope</option> : null}
            {locationsInScope.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
          <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
            Local admin is locked to their assigned location
          </div>
        </div>

        <div style={{ flex: "1 1 240px" }}>
          <div style={{ fontSize: 12, opacity: 0.8 }}>Search</div>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name or unit"
            style={{ width: "100%", padding: 10, marginTop: 6 }}
          />
        </div>

        <div style={{ fontSize: 12, opacity: 0.8 }}>
          {loadingRows ? "Loading" : `Showing ${filtered.length} of ${rows.length}`}
        </div>
      </div>

      <div style={{ marginTop: 18, border: "1px solid rgba(0,0,0,0.15)", borderRadius: 8, padding: 12 }}>
        <div style={{ fontSize: 14, fontWeight: 700 }}>Add tracked item</div>

        <div style={{ marginTop: 10, display: "grid", gap: 10 }}>
          <div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>Name</div>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={{ width: "100%", padding: 10, marginTop: 6 }}
              placeholder="Example dish soap"
            />
          </div>

          <div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>Sub label</div>
            <input
              value={subLabel}
              onChange={(e) => setSubLabel(e.target.value)}
              style={{ width: "100%", padding: 10, marginTop: 6 }}
              placeholder="Optional, example bar or kitchen"
            />
          </div>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Unit</div>
              <input value={unit} onChange={(e) => setUnit(e.target.value)} style={{ width: "100%", padding: 10, marginTop: 6 }} />
            </div>

            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Value per unit</div>
              <input
                value={valuePerUnit}
                onChange={(e) => setValuePerUnit(e.target.value)}
                style={{ width: "100%", padding: 10, marginTop: 6 }}
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Baseline input</div>
              <input
                value={baselineInput}
                onChange={(e) => setBaselineInput(e.target.value)}
                style={{ width: "100%", padding: 10, marginTop: 6 }}
                placeholder="Optional"
              />
            </div>

            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Baseline output</div>
              <input
                value={baselineOutput}
                onChange={(e) => setBaselineOutput(e.target.value)}
                style={{ width: "100%", padding: 10, marginTop: 6 }}
                placeholder="Optional"
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Tolerance green</div>
              <input value={tGreen} onChange={(e) => setTGreen(e.target.value)} style={{ width: "100%", padding: 10, marginTop: 6 }} />
            </div>

            <div style={{ flex: "1 1 220px" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Tolerance yellow</div>
              <input value={tYellow} onChange={(e) => setTYellow(e.target.value)} style={{ width: "100%", padding: 10, marginTop: 6 }} />
            </div>
          </div>

          <div>
            <button onClick={createTrackedItem} disabled={creating || !selectedLocation} style={{ padding: "10px 14px" }}>
              {creating ? "Creating" : "Create tracked item"}
            </button>
          </div>

          {status ? <div style={{ fontSize: 12, opacity: 0.9 }}>{status}</div> : null}
        </div>
      </div>

      <div style={{ marginTop: 18, border: "1px solid rgba(0,0,0,0.15)", borderRadius: 8 }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 120px",
            gap: 10,
            padding: 10,
            fontSize: 12,
            fontWeight: 700,
            opacity: 0.9,
          }}
        >
          <div>Name</div>
          <div>Unit</div>
          <div>Value</div>
          <div>Green</div>
          <div>Yellow</div>
          <div>Active</div>
        </div>

        <div style={{ borderTop: "1px solid rgba(0,0,0,0.1)" }} />

        {filtered.slice(0, 500).map((r) => {
          return (
            <div
              key={r.id}
              style={{
                display: "grid",
                gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 120px",
                gap: 10,
                padding: 10,
                fontSize: 12,
                borderTop: "1px solid rgba(0,0,0,0.06)",
                alignItems: "center",
              }}
            >
              <div style={{ fontWeight: 600 }}>
                <div>{r.name}</div>
                {r.sub_label ? <div style={{ fontSize: 11, opacity: 0.75 }}>{r.sub_label}</div> : null}
                <div style={{ fontSize: 10, opacity: 0.55 }}>{r.id}</div>
              </div>

              <div>
                <input
                  value={r.unit}
                  onChange={(e) => {
                    const v = e.target.value;
                    setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, unit: v } : x)));
                  }}
                  onBlur={() => quickUpdate(r, { unit: r.unit })}
                  style={{ width: "100%", padding: 8 }}
                />
              </div>

              <div>
                <input
                  value={String(r.value_per_unit)}
                  onChange={(e) => {
                    const v = e.target.value;
                    const n = asNumber(v, r.value_per_unit);
                    setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, value_per_unit: n } : x)));
                  }}
                  onBlur={() => quickUpdate(r, { value_per_unit: r.value_per_unit })}
                  style={{ width: "100%", padding: 8 }}
                />
              </div>

              <div>
                <input
                  value={String(r.tolerance_green)}
                  onChange={(e) => {
                    const v = e.target.value;
                    const n = asNumber(v, r.tolerance_green);
                    setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, tolerance_green: n } : x)));
                  }}
                  onBlur={() => quickUpdate(r, { tolerance_green: r.tolerance_green })}
                  style={{ width: "100%", padding: 8 }}
                />
              </div>

              <div>
                <input
                  value={String(r.tolerance_yellow)}
                  onChange={(e) => {
                    const v = e.target.value;
                    const n = asNumber(v, r.tolerance_yellow);
                    setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, tolerance_yellow: n } : x)));
                  }}
                  onBlur={() => quickUpdate(r, { tolerance_yellow: r.tolerance_yellow })}
                  style={{ width: "100%", padding: 8 }}
                />
              </div>

              <div>
                <button onClick={() => toggleActive(r)} style={{ padding: "6px 10px", opacity: r.active ? 1 : 0.6 }}>
                  {r.active ? "Deactivate" : "Activate"}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: 12, fontSize: 12, opacity: 0.7 }}>
        Local admin can manage tracked items only in their assigned location. Regional admin is limited to their region. Master admin can manage all locations.
      </div>
      <CreateEmployeeSection />
    </div>
  );
}
